// ==UserScript==
// @name         dallasnews
// @namespace    http://tampermonkey.net/
// @version      2024-02-28
// @description  try to take over the world!
// @author       You
// @match        https://www.dallasnews.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=dallasnews.com
// @grant        none
// @require      file:///Users/volodymyr.sakharov/projects/tamperMonkey/build/dallasnews/index.js
// ==/UserScript==

